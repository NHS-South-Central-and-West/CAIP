
<!-- README.md is generated from README.Rmd. Please edit that file -->

# CAP

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
[![R-CMD-check](https://github.com/NHS-South-Central-and-West/CAP/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/NHS-South-Central-and-West/CAP/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

PCN Local Capacity and Access Improvement Payment Dashboard
