#' Create filename for downloading GPPT & FFT data and plots
#'
#' @description A fct function
#'
#' @return The return value, if any, from executing the function.
#'
#' @noRd
